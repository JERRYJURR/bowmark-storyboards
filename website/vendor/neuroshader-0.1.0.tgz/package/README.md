# neuroshader

> Author sci-fi, neuro-distorted WebGL effects visually — render them anywhere.

A framework-agnostic WebGL runtime built on [Three.js](https://threejs.org) and
[`postprocessing`](https://github.com/pmndrs/postprocessing). You feed it a small
declarative config; it renders a layered effect onto a canvas.

Configs are authored in **neuroshader studio** and exported as JSON. The editor
previews with this exact runtime, so what you design is what you ship.

## Install

```bash
npm i neuroshader three postprocessing
```

`three` and `postprocessing` are peer-ish dependencies kept external, so your app
resolves a single copy of each.

## Use

```ts
import { createNeuroShader } from 'neuroshader'
import config from './neuroshader.json'

const ns = createNeuroShader(document.querySelector('#bg')!, config)
ns.start()

// later
ns.dispose()
```

The target may be a container element (a canvas is created and sized to it) or a
canvas you already own.

## The model

Six layers, fixed order, effects reordered within each:

| Layer | What it does |
| --- | --- |
| `scene` | Background, fog, lights, shadow ground, backdrop |
| `object` | The geometry being rendered |
| `distortion` | Screen-space warps — lens, ripple, swirl, waves |
| `filter` | Posterize, threshold, solarize, edge detection |
| `blurGlow` | Blur, bloom, depth of field |
| `post` | Noise, dithering, gradient map, colour overlay, glitch |

`scene` and `object` build the Three.js scene. The other four compile, in layer
order, into a `postprocessing` composer chain — one pass per effect.

Each effect instance may set `opacity` and a `blend` mode, the way a layer in a
design tool does.

## API

| Member | Purpose |
| --- | --- |
| `createNeuroShader(target, config, options?)` | Build a runtime |
| `.start()` / `.stop()` | Drive the render loop |
| `.setConfig(config)` | Swap the whole config (structural edits) |
| `.updateParams(id, params)` | Live-edit one effect; `false` means it needs a rebuild |
| `.setBlending(id, patch)` | Live-edit opacity / blend mode |
| `.setPixelRatio(max)` | Cap device pixel ratio — the cheapest lever on cost |
| `.captureThumbnail(w?, h?, q?)` | Next frame as a JPEG blob |
| `.stats` | Resolution, pass chain, frame timing, per-pass GPU ms, estimated memory |
| `.dispose()` | Release the context and all GPU resources |

## Adding an effect

Effects are self-describing manifests in a registry. One `defineEffect()` gives
the runtime a factory and the editor an auto-generated inspector:

```ts
import { defineEffect } from 'neuroshader'
```

Each manifest declares its `type`, `layer`, `label`, and a typed `params` schema.

## Requirements

WebGL2. Desktop-first; mobile works but caps matter — see `setPixelRatio`.

## License

MIT © Jerry Kou
